﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EventsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/events
        [HttpGet]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _context.Events.ToListAsync();
            return Ok(events);
        }

        // GET: api/events/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEventById(int id)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return NotFound("Event not found");
            return Ok(ev);
        }

        // GET: api/events/mine
        [HttpGet("mine")]
        public async Task<IActionResult> GetMyEvents()
        {
            if (!HttpContext.Items.ContainsKey("UserId"))
                return Unauthorized("Not logged in");

            var userId = (int)HttpContext.Items["UserId"];
            var events = await _context.Events.Where(e => e.OrganiserId == userId).ToListAsync();
            return Ok(events);
        }

        // POST: api/events
        [HttpPost]
        public async Task<IActionResult> CreateEvent([FromBody] Event ev)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) // assume RoleId 1 = Organiser
                return Forbid("Only organisers can create events");

            if (!HttpContext.Items.ContainsKey("UserId"))
                return Unauthorized("Not logged in");

            var userId = (int)HttpContext.Items["UserId"];
            ev.OrganiserId = userId;

            _context.Events.Add(ev);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEventById), new { id = ev.EventId }, ev);
        }

        // PUT: api/events/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] Event ev)
        {
            if (!HttpContext.Items.ContainsKey("UserId") || !HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var userId = (int)HttpContext.Items["UserId"];
            var roleId = (int)HttpContext.Items["RoleId"];

            if (roleId != 1) return Forbid("Only organisers can update events");

            var existing = await _context.Events.FindAsync(id);
            if (existing == null) return NotFound("Event not found");
            if (existing.OrganiserId != userId) return Forbid("You can only update your own events");

            existing.Name = ev.Name;
            existing.Description = ev.Description;
            existing.EventDate = ev.EventDate;
            existing.Location = ev.Location;
            existing.DistanceKm = ev.DistanceKm;
            existing.EventType = ev.EventType;

            _context.Events.Update(existing);
            await _context.SaveChangesAsync();

            return Ok(existing);
        }

        // DELETE: api/events/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (!HttpContext.Items.ContainsKey("UserId") || !HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var userId = (int)HttpContext.Items["UserId"];
            var roleId = (int)HttpContext.Items["RoleId"];

            if (roleId != 1) return Forbid("Only organisers can delete events");

            var existing = await _context.Events.FindAsync(id);
            if (existing == null) return NotFound("Event not found");
            if (existing.OrganiserId != userId) return Forbid("You can only delete your own events");

            _context.Events.Remove(existing);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Event deleted successfully" });
        }
    }
}

