﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public CategoriesController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/categories/event/{eventId}
        [HttpGet("event/{eventId}")]
        public async Task<IActionResult> GetCategoriesForEvent(int eventId)
        {
            var categories = await _context.Categories.Where(c => c.EventId == eventId).ToListAsync();
            return Ok(categories);
        }

        // POST: api/categories/event/{eventId}
        [HttpPost("event/{eventId}")]
        public async Task<IActionResult> CreateCategory(int eventId, [FromBody] Category category)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) // assume RoleId 1 = Organiser
                return Forbid("Only organisers can create categories");

            category.EventId = eventId;
            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCategoriesForEvent), new { eventId = eventId }, category);
        }

        // PUT: api/categories/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] Category category)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) return Forbid("Only organisers can update categories");

            var existing = await _context.Categories.FindAsync(id);
            if (existing == null) return NotFound("Category not found");

            existing.Name = category.Name;
            existing.Description = category.Description;

            _context.Categories.Update(existing);
            await _context.SaveChangesAsync();

            return Ok(existing);
        }

        // DELETE: api/categories/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) return Forbid("Only organisers can delete categories");

            var existing = await _context.Categories.FindAsync(id);
            if (existing == null) return NotFound("Category not found");

            _context.Categories.Remove(existing);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Category deleted successfully" });
        }
    }
}
