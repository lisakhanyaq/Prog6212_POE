﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public ResultsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // POST: api/results
        [HttpPost]
        public async Task<IActionResult> CreateResult([FromBody] Result result)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) // assume RoleId 1 = Organiser
                return Forbid("Only organisers can capture results");

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return Ok(result);
        }

        // GET: api/results/mine
        [HttpGet("mine")]
        public async Task<IActionResult> GetMyResults()
        {
            if (!HttpContext.Items.ContainsKey("UserId"))
                return Unauthorized("Not logged in");

            var userId = (int)HttpContext.Items["UserId"];
            var results = await _context.Results
                .Include(r => r.Enrolment)
                .ThenInclude(e => e.Category)
                .Where(r => r.Enrolment.UserId == userId)
                .ToListAsync();

            return Ok(results);
        }

        // GET: api/results/event/{eventId}
        [HttpGet("event/{eventId}")]
        public async Task<IActionResult> GetResultsForEvent(int eventId)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) return Forbid("Only organisers can view event results");

            var results = await _context.Results
                .Include(r => r.Enrolment)
                .ThenInclude(e => e.User)
                .Include(r => r.Enrolment.Category)
                .Where(r => r.Enrolment.Category.EventId == eventId)
                .ToListAsync();

            return Ok(results);
        }
    }
}
