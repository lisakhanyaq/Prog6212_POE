﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // POST: api/enrolments
        [HttpPost]
        public async Task<IActionResult> CreateEnrolment([FromBody] Enrolment enrolment)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 2) // assume RoleId 2 = Participant
                return Forbid("Only participants can enrol");

            if (!HttpContext.Items.ContainsKey("UserId"))
                return Unauthorized("Not logged in");

            var userId = (int)HttpContext.Items["UserId"];
            enrolment.UserId = userId;

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return Ok(enrolment);
        }

        // GET: api/enrolments/mine
        [HttpGet("mine")]
        public async Task<IActionResult> GetMyEnrolments()
        {
            if (!HttpContext.Items.ContainsKey("UserId"))
                return Unauthorized("Not logged in");

            var userId = (int)HttpContext.Items["UserId"];
            var enrolments = await _context.Enrolments
                .Include(e => e.Category)
                .Where(e => e.UserId == userId)
                .ToListAsync();

            return Ok(enrolments);
        }

        // GET: api/enrolments/event/{eventId}
        [HttpGet("event/{eventId}")]
        public async Task<IActionResult> GetEnrolmentsForEvent(int eventId)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) return Forbid("Only organisers can view event enrolments");

            var enrolments = await _context.Enrolments
                .Include(e => e.User)
                .Include(e => e.Category)
                .Where(e => e.Category.EventId == eventId)
                .ToListAsync();

            return Ok(enrolments);
        }

        // PUT: api/enrolments/{id}/status
        [HttpPut("{id}/status")]
        public async Task<IActionResult> UpdateEnrolmentStatus(int id, [FromBody] string status)
        {
            if (!HttpContext.Items.ContainsKey("RoleId"))
                return Unauthorized("Not logged in");

            var roleId = (int)HttpContext.Items["RoleId"];
            if (roleId != 1) return Forbid("Only organisers can update enrolments");

            var enrolment = await _context.Enrolments.FindAsync(id);
            if (enrolment == null) return NotFound("Enrolment not found");

            enrolment.Status = status;
            _context.Enrolments.Update(enrolment);
            await _context.SaveChangesAsync();

            return Ok(enrolment);
        }
    }
}
